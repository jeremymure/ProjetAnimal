/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author murej
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Chat unChat= new Chat ("Félix","Joueur",5);
        System.out.println(unChat.toString());
        System.out.println(unChat.crier());
         
        Chien unChien= new Chien ("Snoopy","Malin",8);
        System.out.println(unChien.toString());
        System.out.println(unChien.crier());
    }
    
}
