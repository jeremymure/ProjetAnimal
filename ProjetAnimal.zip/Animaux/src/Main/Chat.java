/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author murej
 */
public class Chat extends Animal{
    String crie="Miaou";
    public Chat(String nom, String caractere, int age) {
        super(nom, caractere, age);
    }
    
      @Override
    public String toString() {
        return ("Chat : " +"nom = "+ nom + ", caractere = "+ caractere + ", age = " + age +" ans" );
    }
    
public String crier () {
    return crie;
}   

    }


